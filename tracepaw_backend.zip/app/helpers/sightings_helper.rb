module SightingsHelper
end
